export interface User{
    id: number;
    name: string;
    email: string;
    //email?: string; - ? makes it optional

}