import {Component} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgIf} from '@angular/common';

interface ContactFormModel {
  name: string;
  email: string;
}


@Component({
  selector: 'app-contact-form',
  standalone: true,
  imports: [
    FormsModule,
    NgIf
  ],
  templateUrl: './contact-form.component.html',
  styleUrl: './contact-form.component.css'
})
export class ContactFormComponent {

  model: ContactFormModel = {
    name: '',
    email: ''
  };

  onSubmit(form: NgForm) {
    if (form.valid) {
      console.log('Form submitted');
    } else {
      console.log('Form invalid');
    }
  }
}
