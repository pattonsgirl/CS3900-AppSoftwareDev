import {Component, OnInit} from '@angular/core';
import {UserService} from '../services/user.service';
import {AsyncPipe, NgForOf} from '@angular/common';
import {User} from '../../models/user.model';
import {UserHttpService} from '../services/user-http.service';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [
    NgForOf,
    AsyncPipe
  ],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent implements OnInit{
   users: User[] = [];
   errorMessage: string = 'Failed to load users';

  constructor(private userService: UserHttpService) {}


  ngOnInit(): void {
    console.log('Component initialized');

    this.userService.getUsers().subscribe({
      next: (users) => {
        this.users = users;
      },
      error: (err) =>{
        this.errorMessage = err;
        console.error(err);
      },
      complete: () => console.log('Completed')
    }, () => console.log('Subscription completed'));

    this.simulateAsyncOperation();
  }


  simulateAsyncOperation(): void {
    const observable = new Observable<string>((observer) => {
      setTimeout(() => {
        observer.next('First data package');
        observer.next('Second data package');
        observer.complete();
      }, 2000);
    });

    observable.subscribe({
      next: (data) => console.log('Async operation data:', data),
      complete: () => console.log('Async operation completed.'),
    });
  }
}
