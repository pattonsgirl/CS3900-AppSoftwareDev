export interface WorkOrderDetail {
  WorkOrderNumber:  number;
  SKUCode: string;
  Quantity: number;
  UnitCost: number;
  Taxable: boolean;
  Tax: number;
}
