export interface CarouselData {
  displayText: string;
  image: string; // image url
}
