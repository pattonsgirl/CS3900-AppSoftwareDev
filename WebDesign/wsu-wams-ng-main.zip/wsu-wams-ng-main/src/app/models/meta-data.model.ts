export interface MetaData {
  message: string;
  pageCount: number;
  resultCount: number;
}
