export enum SortOrder {
  Ascending = 'asc',
  Descending = 'desc',

}
