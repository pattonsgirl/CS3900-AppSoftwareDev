import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserComponent } from './user.component';
import { User } from '../../models/user.model';
import { of } from 'rxjs';
import {provideRouter} from '@angular/router';
import {UserService} from '../../services/user.service';

class MockUserService {
  users: User[] = [
    {
      id:1,
      name:'John Doe',
      email: 'john@doe.com'
    },
    {
      id: 2,
      name: 'Jane Doe',
      email: 'jane@doe.com'
    }
  ];

  getUsers(): User[] {
    return this.users;
  }

  addUser(user: User) {
    this.users.push(user);
  }
}

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;
  let userService: UserService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserComponent],
      providers: [provideRouter([]), { provide: UserService, useClass: MockUserService}]
    })
    .compileComponents();
    userService = TestBed.inject(UserService);
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    component.loadUsers(); // initialize this to an empty array so fixture.detectChanges does NOT flag an issue with iterables
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select user', () => {
    const userToSelect: User = { // create static user with which to test our component's method
      id:45,
      name: 'Jesse James',
      email: 'outlaw@wild.west'
    }
    component.selectUser(userToSelect); // run that method using our static object above
    expect(component.selectedUser).toBe(userToSelect); // check the value to ensure the method ran as it should have
  });

  /*
    Below are tests utilizing our mocked service from above, please note that all unit tests in this COMPONENT
    spec.ts file should be directly related to how the component interacts with the service (see how all values
    below being tested and compared are at the component level after utilizing the service)
  */
  it('should get and set user data', () => { // lets test our component's functionality that leverages the service
    const userToAdd: User = { // create a static user to add later
      id: 47,
      name: 'Ralph Oswald',
      email: 'oldman@gmail.com'
    };
    component.loadUsers(); // utilize getter to fetch users

    expect(component.users).toEqual([{ // compare the user component's array of users against the hardcoded one above after we run the getter to test it
      id:1,
      name:'John Doe',
      email: 'john@doe.com'
    },
      {
        id: 2,
        name: 'Jane Doe',
        email: 'jane@doe.com'
      }]);

    component.addUser(userToAdd); // now test the setter!
    expect(component.users[2]).toBe(userToAdd); // ensure the most recent user in that array is the hardcoded one we just added!
  });
});
